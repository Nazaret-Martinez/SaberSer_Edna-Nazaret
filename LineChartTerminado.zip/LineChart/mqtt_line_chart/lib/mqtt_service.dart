import 'package:mqtt_client/mqtt_client.dart'; //Importar la biblioteca MQTT Client
import 'package:mqtt_client/mqtt_server_client.dart'; //Importar la biblioteca MQTT Server Client

class MqttService{
  final MqttServerClient client; // declaracion del cliente MQTT

  //Constructor de MqttService que inicializa el cliente MQTT
  MqttService(String server, String clientId)
      : client = MqttServerClient(server, '') {
    //Asegurate de que el clientId sea valido
    const sanitizedClientId = '';

    client.logging(on: true); //Habilita el logging para el cliente MQTT
    client.setProtocolV31(); //Configura el protocolo MQTT 3.1.1
    client.keepAlivePeriod =
        20; //Configura el periodo de keep alive en 20 segundos

    //Configuracion del mensaje de conexion
    final connMessage = MqttConnectMessage()
        .withClientIdentifier(sanitizedClientId) //Identificador del cliente
        .startClean() //Indentifica que el cliente debe comenzar con una sesion limpia
        .withWillQos(MqttQos
            .atLeastOnce); //Configura el QoS para el mensaje de "Ultima voluntad"
    client.connectionMessage = 
      connMessage; //Asigna el mensaje de conexion al cliente
      }


//Metodo que retorna un stream de datos de temperatura 
  Stream<double> getTemperatureStream() async* {
    try {
      //Intentar conectar al servidor MQTT
      await client.connect();
    } catch (e) {
      //Si la conexion falla, desconecta el cliente y retorna
      client.disconnect();
      return;
    }

    //Verifica si la conexion fue exitosa
    if (client.connectionStatus?.state == MqttConnectionState.connected){
      //se suscribe al topico de temperatura con Qos 1
      client.subscribe("temperature/topic", MqttQos.atLeastOnce);

      //Escucha los mensajes entrantes y emite los valores de temperatura 
      await for (final c in client.updates!){
        final MqttPublishMessage recMess = 
            c[0].payload as MqttPublishMessage; //Obtiene el mensaje publico
        final String pt = MqttPublishPayload.bytesToString(
            recMess.payload.message); //Convierte el payload a String
        yield double.tryParse(pt) ??
            0.0; //convierte el payload a double y lo emite en el stream
      }
    } else {
      //si la conexion no fue exitosa, desconecta el cliente
      client.disconnect();
    }
  }
}