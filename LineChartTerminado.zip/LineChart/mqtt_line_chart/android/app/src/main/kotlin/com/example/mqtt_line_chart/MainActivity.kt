package com.example.mqtt_line_chart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
