package com.example.gauge_mqtt_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
