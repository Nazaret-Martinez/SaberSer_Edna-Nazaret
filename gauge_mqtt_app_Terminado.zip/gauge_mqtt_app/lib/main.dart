import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart'; //Importar la biblioteca para el gauge
import 'mqtt_service.dart'; //importar el servicio Mqtt

void main() {
  runApp(const MyApp()); //Llama a reunApp para iniciar la aplicacion 
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  
  @override
  Widget build(BuildContext){
    return MaterialApp(
      title: 'Gauge MQTT App', //Titulo de la aplicacion
      theme: ThemeData(
        primarySwatch: Colors.blue, //Tema principal de la aplicacion
      ),
      home: const GaugeScreen(), //Define GaugeScreen como la pantalla principal
    );
  }
}

//GaugeScreen es un statefulWidget que mostrara el gauge de temperatura 
class GaugeScreen extends StatefulWidget{
  const GaugeScreen({super.key});

  @override 
  _GaugeScreenState createState() => _GaugeScreenState(); //crea el estado asociado a este widget
}

//_GaugeScreenState contiene el estado del widget GaugeScreen
class _GaugeScreenState extends State<GaugeScreen> {
  late MqttService _mqttService; //Declaracion del servicio MQTT
  double _temperature = 0.0; //Variable para almacenar la temperatura actual 

  @override
  void initState() {
    super.initState();
    //Inicializa el servicio MQTT con el broker y el clienId
    _mqttService = MqttService('broker.emqx.io', '');
    //Escucha el stream de temperatura y actualiza el estado cuando llegue un nuevo valor
    _mqttService.getTemperatureStream().listen((temperature){
      setState(() {
        _temperature =temperature; //Actualiza la temperatura
      });
    });
   }
///checar corchetes att: gpuente
   @override 
   Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: const Text('Temperature Gauge'), //Tutulo de la barra de la aplicacion
      ),
      body: Center(
        //contenedor principal de la pantalla
        child: SfRadialGauge(
          //Widget para mostrar el gauge radial
          axes: <RadialAxis>[
            RadialAxis(
              //Configuracion del eje radial
              minimum: -20, //valor minimo del gauge
              maximum: 50, //valor maximo del gauge
              ranges: <GaugeRange>[
                //Definicion de rangos de colores en el gauge
                GaugeRange(startValue: -20, endValue: 0, color: Colors.blue), //Rango azul para temperaturas frias
                GaugeRange(startValue: 0, endValue: 25, color: Colors.green), //Rango verde para temperaturas moderadas 
                GaugeRange(startValue: 25, endValue: 50, color: Colors.red), //Rango rojo para temperaturas calientes
              ],
              pointers: <GaugePointer>[
                //Aguja del gauge que indica la temperatura actual
                NeedlePointer(value: _temperature),
              ],
              annotations: <GaugeAnnotation>[
                //Anotacion que muestra el valor de la temperatura en el centro del gauge
                GaugeAnnotation(
                  widget: Text(
                    '$_temperature°C', //Muestra la temperatura con un formato de texto
                    style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.bold), //Estilo del texto //TextStyle
                      ),
                      angle: 90, //Angulo de la anotacion
                      positionFactor: 0.5,//Posicion de la anotacion del gauge
                  ),
              ],
            ),
          ],
        ),
      ),
    );
   }
   }
   //checar corchetes att: gpuente