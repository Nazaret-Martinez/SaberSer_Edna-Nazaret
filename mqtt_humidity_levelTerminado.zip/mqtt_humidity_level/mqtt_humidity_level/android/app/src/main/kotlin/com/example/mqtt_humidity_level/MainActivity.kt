package com.example.mqtt_humidity_level

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
